module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return res.status(503).json({ error: 'Database environment variables are not configured' });
  }

  const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
  const name = String(body.name || '').trim();
  const phone = String(body.phone || '').trim();
  const service = String(body.service || '').trim();

  if (!name || !phone || !service) {
    return res.status(400).json({ error: 'Name, phone and service are required' });
  }

  const clean = {
    name: name.slice(0, 80),
    phone: phone.slice(0, 30),
    service: service.slice(0, 80),
    people_count: Number.isFinite(Number(body.people_count)) ? Number(body.people_count) : null,
    event_date: body.event_date || null,
    location: body.location ? String(body.location).trim().slice(0, 160) : null,
    message: body.message ? String(body.message).trim().slice(0, 1200) : null,
    source: 'website'
  };

  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/inquiries`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal'
      },
      body: JSON.stringify(clean)
    });

    if (!response.ok) {
      const detail = await response.text();
      console.error('Supabase insert failed:', response.status, detail);
      return res.status(500).json({ error: 'Could not save inquiry' });
    }

    return res.status(201).json({ ok: true });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Unexpected server error' });
  }
};
